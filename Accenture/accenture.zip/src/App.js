import './App.css';
import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import Frontpage from './Frontpage/Frontpage';
import Course from './Course/Course';
import Activity from './Activity/Activity';
import { Route, Routes } from 'react-router-dom';
import Successpage from './Successpage';
import Logout from './Logout';
import { useNavigate } from "react-router-dom";
function App() {
  const navigate = useNavigate();
  const routeChange = () =>{ 
    navigate("/Frontpage");
  }
  return (
    <div>
<button onClick={routeChange}>Home</button>
    <div>
      <Routes>
        <Route path='/Frontpage' element={<Frontpage />} />
        <Route path='/Course' element={<Course />} />
        <Route path="/Activity" element={<Activity />} />
        <Route path='/Successpage' element={<Successpage />} />
        <Route path='/Logout' element={<Logout />} />
      </Routes>
      </div></div>
     
  );
}

export default App;
