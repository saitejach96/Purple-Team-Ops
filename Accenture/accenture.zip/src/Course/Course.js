import 'bootstrap/dist/css/bootstrap.min.css';
import React,{useState,useEffect} from 'react';
import academy from'../img/academy.jpg';
import logo from '../img/logo.jpg';
import  data from '../sample.json';
import { useNavigate } from "react-router-dom";
function Course(props) {
  
  const navigate = useNavigate();
  const pageChange = () =>{ 
    navigate("/Activity");
  }
  const logoutChange = () =>{ 
    navigate("/Logout");
  }
  return (
    <div>
        <div class="header-blue" >
            <nav class="navbar navbar-light navbar-expand-md navigation-clean-search">
                <p>{props.name}</p>
                <div><img src="https://i.imgur.com/CXQmsmF.png" class="logo" /></div>
                <div style={{marginLeft:'400px',color:'yellow'}}><h1>Course</h1></div>
                  <div style={{marginLeft:'400px'}}><button type="submit" class="btn btn-light" onClick={logoutChange}>logout</button></div>  
            </nav></div>
           
              <div class='line'></div>  
        <div style={{display:'flex',marginLeft:'50px'}}>{
        data.map((item)=>
       <div style={{ backgroundColor:'purple',textAlign:'center',marginTop:'20px',
        borderRadius:'5px',  fontFamily : 'Source Sans Pro' ,width:'250px' ,
         height:'350px', margin:'10px' ,border: '2px solid black',padding: '5px'  } }>
          <p style={{marginTop:'5px'}}><b>Course Name</b>: {item.coursename}</p>
          <p><b>Start Date</b>: {item.startdate}</p>
          <p><b>End Date</b>: {item.enddate}</p>
          <p ><b>discription</b>: {item.discription}</p>
          <button type="submit" class="btn btn-primary" onClick={pageChange}>start</button>
       </div>)}</div>
 
       <div class='line'></div>

          <div style={{textAlign:'center',marginBottom:'10px',fontWeight:'bold',
         fontFamily : 'Source Sans Pro' , margin:'10px' ,padding: '5px'}}>Copyright &copy; 2022. All rights reserved.</div> 



                </div>

  );
}

export default Course;
