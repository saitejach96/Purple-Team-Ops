import React from "react";

function Logout(){
return(
<div style={{
     margin: '0',
     position: 'absolute',
     top: '50%',
     left: '50%',
     marginRight:'-50%',
     transform: 'translate(-50%, -50%)'}}>
<h1>Succesfully Logout</h1>

</div>);
}

export default  Logout;