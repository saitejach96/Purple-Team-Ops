import logo from '../img/logo.jpg';
import React from 'react';
import data from "../activity.json";
import { useNavigate } from "react-router-dom";
function Activity() {
    const navigate = useNavigate();
    const finalpageChange = () =>{ 
      navigate("/Successpage");
    }
    const logoutChange = () =>{ 
      navigate("/Logout");
    }
  return (
<div>
        <div class="header-blue">
            <nav class="navbar navbar-light navbar-expand-md navigation-clean-search">
              
                <div><img src="https://i.imgur.com/CXQmsmF.png" class="logo" /></div>
                <div style={{marginLeft:'400px',color:'white'}}><h1 >Activity</h1></div>
                  <div style={{marginLeft:'400px'}}><button type="submit" class="btn btn-light" onClick={logoutChange}>logout</button></div>  
            </nav></div>
           
              <div class='line'></div>  
        <div style={{display:'grid',grid: '180px / auto auto auto', gridGap:'10px', marginLeft:'50px'}}>{
        data.map((item)=>
       <div style={{ backgroundColor:'purple',textAlign:'center',marginTop:'20px',
        borderRadius:'5px',  fontFamily : 'Source Sans Pro' ,width:'250px' ,
         height:'180px', margin:'10px' ,border: '2px solid black',padding: '5px'  } }>
          <p style={{marginTop:'5px'}}><b>Activity Name</b>: {item.activityname}</p>
           <b>Icon</b>:<img src={item.icon}></img>
          <p ><b>Details</b>: {item.details}</p>
          <button type="submit" class="btn btn-primary" onClick={finalpageChange}>start</button>
       </div>)}</div>
 
       <div class='line'></div>

          <div style={{textAlign:'center',marginBottom:'10px',fontWeight:'bold',
         fontFamily : 'Source Sans Pro' , margin:'10px' ,padding: '5px'}}>Copyright &copy; 2022. All rights reserved.</div> 



                </div>
   
     
  );
}

export default Activity;
