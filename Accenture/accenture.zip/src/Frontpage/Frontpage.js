import './Frontpage.css';
import React, { useState, useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import academy from'../img/academy.jpg';
import logo from '../img/logo.jpg';
import { useNavigate } from "react-router-dom";
import Course from '../Course/Course';

function Frontpage() {
    const [data, setdata] = useState('');
    const [password, setpassword] = useState('');
  const navigate = useNavigate();
  const routeChange = () =>{ 
    navigate("/Course");
  }
  const handlesumbit = () => {
    alert(data, password);
  }
  return (
    
    <div class="container-fluid px-1 px-md-5 px-lg-1 px-xl-5 py-5 mx-auto">
    <div class="card card0 border-0">
        <div class="row d-flex">
            <div class="col-lg-6">
                <div class="card1 pb-5">
                    <div class="row">
                        <img src="https://i.imgur.com/CXQmsmF.png" class="logo" />
                    </div>
                    <div class="row px-3 justify-content-center mt-4 mb-5 border-line">
                        <img src="https://i.imgur.com/uNGdWHi.png" class="image" />
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="card2 card border-0 px-4 py-5">
                    <div class="row mb-4 px-3">
                      <div  class="container-fluid"> 
                      <div class="row">
                      <div class="col"><a class="nav-link" href="#">About</a></div>
                      <div class="col"><a class="nav-link" href="#">Career</a></div>
                      <div class="col"><a class="nav-link" href="#">Contact</a></div>
                     </div> </div>
                    </div>
                   <div class='pageinfo'>
                    <div class="row px-3">
                        <label class="mb-1"><h6 class="mb-0 text-sm">Name</h6></label>
                        <input class="mb-4" type="text" name="Name" placeholder="Enter a valid Name" onChange={(e)=>setdata(e.target.value)} required/>
                    </div>
                    <div class="row px-3">
                        
                        <label class="mb-1"><h6 class="mb-0 text-sm">Password</h6></label>
                        <input type="password" name="password" placeholder="Enter password" onChange={(e)=>setpassword(e.target.value)}  required/>
                    </div>
                    <br></br>
                    <div class="row mb-3 px-3">
                    <button type="submit" class="btn btn-blue text-center"  onClick={routeChange} onSubmit={handlesumbit}>Login</button>
                    </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="bg-blue py-4">
            <div class="row px-3">  
                <div style={{textAlign:'center'}}><small class="ml-4 ml-sm-5 mb-2">Copyright &copy; 2022. All rights reserved.</small></div> 
            </div>
        </div>
    </div>
</div>

  );
}

export default Frontpage;